# rich menu

[Using rich menus](https://developers.line.biz/en/docs/messaging-api/using-rich-menus/)

## Getting started

```
$ export LINE_CHANNEL_ACCESS_TOKEN=YOUR_LINE_CHANNEL_ACCESS_TOKEN
$ pip install -r requirements.txt
$ python app.py
```
